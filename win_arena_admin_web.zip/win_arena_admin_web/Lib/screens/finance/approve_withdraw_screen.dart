import 'package:flutter/material.dart';
import '../../constants/colors.dart';
import '../../widgets/tables/withdrawals_table.dart';

class ApproveWithdrawScreen extends StatelessWidget {
  const ApproveWithdrawScreen({super.key});

  // Fixed withdrawal account details
  final String accountName = 'Syed Asif Ali Shah';
  final String accountNumber = '03234227193';
  final String provider = 'JazzCash';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: const Text(
          'Approve Withdrawals',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              color: AppColors.cardBackground,
              child: ListTile(
                title: Text(
                  'Account: $accountName',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text('Number: $accountNumber\nProvider: $provider'),
                trailing: const Icon(Icons.account_balance_wallet),
              ),
            ),
            const SizedBox(height: 20),
            const Expanded(
              child: WithdrawalsTable(), // Table widget showing withdrawal requests
            ),
          ],
        ),
      ),
    );
  }
}