import 'package:qr_flutter/qr_flutter.dart';
import 'package:flutter/material.dart';

class QRHelper {
  static Widget generateQR(String data,
      {double size = 180, Color backgroundColor = Colors.white}) {
    return Container(
      padding: const EdgeInsets.all(12),
      color: backgroundColor,
      child: QrImageView(
        data: data,
        size: size,
        version: QrVersions.auto,
      ),
    );
  }

  static String generateTournamentQR(String tournamentId) {
    return "win-arena:tournament:$tournamentId";
  }

  static String generateUserQR(String userId) {
    return "win-arena:user:$userId";
  }
}