import 'dart:convert';
import 'package:http/http.dart' as http;

class UserService {
  final String baseUrl = "https://yourwebsite.com/api";

  Future<List<dynamic>> getAllUsers() async {
    final response = await http.get(
      Uri.parse("$baseUrl/users.php"),
    );
    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> blockUser(String userId) async {
    final response = await http.post(
      Uri.parse("$baseUrl/block_user.php"),
      body: {"user_id": userId},
    );
    return jsonDecode(response.body);
  }
}