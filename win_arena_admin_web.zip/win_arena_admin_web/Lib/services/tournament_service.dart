import 'dart:convert';
import 'package:http/http.dart' as http;

class TournamentService {
  final String baseUrl = "https://yourwebsite.com/api";

  Future<List<dynamic>> getTournaments() async {
    final response = await http.get(
      Uri.parse("$baseUrl/tournaments.php"),
    );
    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> createTournament(Map<String, dynamic> data) async {
    final response = await http.post(
      Uri.parse("$baseUrl/create_tournament.php"),
      body: data,
    );
    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> updateTournament(Map<String, dynamic> data) async {
    final response = await http.post(
      Uri.parse("$baseUrl/update_tournament.php"),
      body: data,
    );
    return jsonDecode(response.body);
  }
}