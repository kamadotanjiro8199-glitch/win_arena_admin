import 'package:get/get.dart';
import '../services/auth_service.dart';
import '../models/admin_model.dart';

class AuthController extends GetxController {
  final AuthService _authService = AuthService();

  RxBool loading = false.obs;
  Rxn<AdminModel> admin = Rxn<AdminModel>();

  Future<bool> login(String email, String password) async {
    loading.value = true;
    final result = await _authService.loginAdmin(email, password);
    loading.value = false;

    if (result != null) {
      admin.value = result;
      return true;
    }
    return false;
  }

  void logout() {
    admin.value = null;
    _authService.logoutAdmin();
  }
}