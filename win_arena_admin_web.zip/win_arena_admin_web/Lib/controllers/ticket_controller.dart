import 'package:get/get.dart';
import '../models/ticket_model.dart';
import '../services/ticket_service.dart';

class TicketController extends GetxController {
  final TicketService _ticketService = TicketService();

  RxBool loading = false.obs;
  RxList<TicketModel> tickets = <TicketModel>[].obs;

  Future<void> fetchTickets() async {
    loading.value = true;
    tickets.value = await _ticketService.getAllTickets();
    loading.value = false;
  }

  Future<void> closeTicket(String id) async {
    await _ticketService.closeTicket(id);
    fetchTickets();
  }
}