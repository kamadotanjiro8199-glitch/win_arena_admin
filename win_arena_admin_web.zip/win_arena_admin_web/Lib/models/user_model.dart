class UserModel {
  final String id;
  final String username;
  final String email;
  final String phone;
  final String ffUid;
  final String profileImage;
  final int matches;
  final int wins;
  final int kills;
  final int walletBalance;
  final bool isBanned;

  UserModel({
    required this.id,
    required this.username,
    required this.email,
    required this.phone,
    required this.ffUid,
    required this.profileImage,
    required this.matches,
    required this.wins,
    required this.kills,
    required this.walletBalance,
    required this.isBanned,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json["id"] ?? "",
      username: json["username"] ?? "",
      email: json["email"] ?? "",
      phone: json["phone"] ?? "",
      ffUid: json["ff_uid"] ?? "",
      profileImage: json["profile_image"] ?? "",
      matches: json["matches"] ?? 0,
      wins: json["wins"] ?? 0,
      kills: json["kills"] ?? 0,
      walletBalance: json["wallet_balance"] ?? 0,
      isBanned: json["is_banned"] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "username": username,
      "email": email,
      "phone": phone,
      "ff_uid": ffUid,
      "profile_image": profileImage,
      "matches": matches,
      "wins": wins,
      "kills": kills,
      "wallet_balance": walletBalance,
      "is_banned": isBanned,
    };
  }
}