import 'package:flutter/material.dart';
import '../../models/user_model.dart';

class UsersTable extends StatelessWidget {
  final List<UserModel> users;

  const UsersTable({super.key, required this.users});

  @override
  Widget build(BuildContext context) {
    return DataTable(
      columns: const [
        DataColumn(label: Text('ID', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Name', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Email', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('UID', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Coins', style: TextStyle(color: Colors.white))),
      ],
      rows: users
          .map(
            (user) => DataRow(cells: [
              DataCell(Text(user.id.toString(), style: const TextStyle(color: Colors.white))),
              DataCell(Text(user.name, style: const TextStyle(color: Colors.white))),
              DataCell(Text(user.email, style: const TextStyle(color: Colors.white))),
              DataCell(Text(user.ffUid, style: const TextStyle(color: Colors.white))),
              DataCell(Text(user.coins.toString(), style: const TextStyle(color: Colors.white))),
            ]),
          )
          .toList(),
    );
  }
}