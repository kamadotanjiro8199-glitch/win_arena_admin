import 'package:flutter/material.dart';
import 'constants/colors.dart';
import 'constants/strings.dart';
import 'constants/images.dart';
import 'screens/auth/admin_login_screen.dart';
import 'screens/dashboard/admin_dashboard_screen.dart';
import 'screens/finance/approve_withdraw_screen.dart';

class WinArenaAdminApp extends StatelessWidget {
  const WinArenaAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Win Arena - Admin',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: AppColors.primary,
        scaffoldBackgroundColor: AppColors.background,
        useMaterial3: true,
        textTheme: Theme.of(context)
            .textTheme
            .apply(bodyColor: AppColors.text, displayColor: AppColors.text),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          elevation: 0,
          backgroundColor: AppColors.background,
        ),
      ),
      initialRoute: AdminRoutes.login,
      routes: {
        AdminRoutes.login: (_) => const AdminLoginScreen(),
        AdminRoutes.dashboard: (_) => const AdminDashboardScreen(),
        AdminRoutes.approveWithdraw: (_) => const ApproveWithdrawScreen(),
        // add other routes here
      },
    );
  }
}

class AdminRoutes {
  static const String login = '/';
  static const String dashboard = '/dashboard';
  static const String approveWithdraw = '/finance/approve-withdraw';
}