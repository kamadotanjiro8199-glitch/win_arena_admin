import 'package:get/get.dart';
import '../models/tournament_model.dart';
import '../services/tournament_service.dart';

class TournamentController extends GetxController {
  final TournamentService _tournamentService = TournamentService();

  RxBool loading = false.obs;
  RxList<TournamentModel> tournaments = <TournamentModel>[].obs;

  Future<void> fetchTournaments() async {
    loading.value = true;
    tournaments.value = await _tournamentService.getAllTournaments();
    loading.value = false;
  }

  Future<void> approveResult(String tournamentId) async {
    await _tournamentService.approveTournamentResult(tournamentId);
    fetchTournaments();
  }

  Future<void> deleteTournament(String id) async {
    await _tournamentService.deleteTournament(id);
    fetchTournaments();
  }
}