class TournamentModel {
  final String id;
  final String title;
  final String type; // Solo / Duo / Squad
  final String map;
  final int entryFee;
  final int prizePool;
  final int slots;
  final int joinedPlayers;
  final String status; // upcoming / ongoing / completed
  final DateTime startTime;
  final String roomId;

  TournamentModel({
    required this.id,
    required this.title,
    required this.type,
    required this.map,
    required this.entryFee,
    required this.prizePool,
    required this.slots,
    required this.joinedPlayers,
    required this.status,
    required this.startTime,
    required this.roomId,
  });

  factory TournamentModel.fromJson(Map<String, dynamic> json) {
    return TournamentModel(
      id: json["id"] ?? "",
      title: json["title"] ?? "",
      type: json["type"] ?? "",
      map: json["map"] ?? "",
      entryFee: json["entry_fee"] ?? 0,
      prizePool: json["prize_pool"] ?? 0,
      slots: json["slots"] ?? 0,
      joinedPlayers: json["joined_players"] ?? 0,
      status: json["status"] ?? "upcoming",
      startTime: DateTime.tryParse(json["start_time"] ?? "") ?? DateTime.now(),
      roomId: json["room_id"] ?? "",
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "title": title,
      "type": type,
      "map": map,
      "entry_fee": entryFee,
      "prize_pool": prizePool,
      "slots": slots,
      "joined_players": joinedPlayers,
      "status": status,
      "start_time": startTime.toIso8601String(),
      "room_id": roomId,
    };
  }
}