import 'package:flutter/material.dart';

class ErrorDialog extends StatelessWidget {
  final String message;
  final VoidCallback? onClose;

  const ErrorDialog({super.key, required this.message, this.onClose});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xff1c1c1e),
      content: Row(
        children: [
          const Icon(Icons.error, color: Colors.redAccent, size: 36),
          const SizedBox(width: 12),
          Expanded(child: Text(message, style: const TextStyle(color: Colors.white))),
        ],
      ),
      actions: [
        ElevatedButton(
          onPressed: onClose ?? () => Navigator.pop(context),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
          child: const Text('Close'),
        )
      ],
    );
  }
}