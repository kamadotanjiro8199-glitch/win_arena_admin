import 'package:flutter/material.dart';
import '../../models/ticket_model.dart';

class ActivityLogsTable extends StatelessWidget {
  final List<Map<String, dynamic>> logs;

  const ActivityLogsTable({super.key, required this.logs});

  @override
  Widget build(BuildContext context) {
    return DataTable(
      columns: const [
        DataColumn(label: Text('ID', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Action', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Admin', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Date', style: TextStyle(color: Colors.white))),
      ],
      rows: logs
          .map(
            (log) => DataRow(cells: [
              DataCell(Text(log['id'].toString(), style: const TextStyle(color: Colors.white))),
              DataCell(Text(log['action'], style: const TextStyle(color: Colors.white))),
              DataCell(Text(log['admin'], style: const TextStyle(color: Colors.white))),
              DataCell(Text(log['date'].toString(), style: const TextStyle(color: Colors.white))),
            ]),
          )
          .toList(),
    );
  }
}