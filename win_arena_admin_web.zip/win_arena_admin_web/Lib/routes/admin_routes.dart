import 'package:flutter/material.dart';
import '../screens/auth/admin_login_screen.dart';
import '../screens/dashboard/admin_dashboard_screen.dart';
import '../screens/dashboard/recent_activity_screen.dart';
import '../screens/users/user_management_screen.dart';
import '../screens/tournaments/tournament_management_screen.dart';
import '../screens/finance/approve_withdraw_screen.dart';
import '../screens/finance/revenue_screen.dart';
import '../screens/payments/payment_setup_screen.dart';
import '../screens/reports/ticket_reports_screen.dart';
import '../screens/settings/app_settings_screen.dart';
import '../screens/settings/admin_account_screen.dart';
import '../screens/settings/activity_logs_screen.dart';

class AdminRoutes {
  static const String login = '/login';
  static const String dashboard = '/dashboard';
  static const String recentActivity = '/recent-activity';
  static const String usersManagement = '/users-management';
  static const String tournamentsManagement = '/tournaments-management';
  static const String approveWithdraw = '/approve-withdraw';
  static const String revenue = '/revenue';
  static const String paymentSetup = '/payment-setup';
  static const String ticketReports = '/ticket-reports';
  static const String appSettings = '/app-settings';
  static const String adminAccount = '/admin-account';
  static const String activityLogs = '/activity-logs';

  static Map<String, WidgetBuilder> routes = {
    login: (context) => const AdminLoginScreen(),
    dashboard: (context) => const AdminDashboardScreen(),
    recentActivity: (context) => const RecentActivityScreen(),
    usersManagement: (context) => const UserManagementScreen(),
    tournamentsManagement: (context) => const TournamentManagementScreen(),
    approveWithdraw: (context) => const ApproveWithdrawScreen(),
    revenue: (context) => const RevenueScreen(),
    paymentSetup: (context) => const PaymentSetupScreen(),
    ticketReports: (context) => const TicketReportsScreen(),
    appSettings: (context) => const AppSettingsScreen(),
    adminAccount: (context) => const AdminAccountScreen(),
    activityLogs: (context) => const ActivityLogsScreen(),
  };
}