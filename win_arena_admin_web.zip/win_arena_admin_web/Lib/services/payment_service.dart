class PaymentService {
  final String fixedName = "Syed Asif Ali Shah";
  final String fixedNumber = "03234227193";
  final String fixedMethod = "JazzCash";

  Map<String, String> getFixedAccount() {
    return {
      "name": fixedName,
      "number": fixedNumber,
      "method": fixedMethod,
    };
  }
}