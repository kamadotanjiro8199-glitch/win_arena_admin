import 'package:flutter/material.dart';
import '../../models/wallet_model.dart';

class WithdrawalsTable extends StatelessWidget {
  final List<WalletModel> withdrawals;

  const WithdrawalsTable({super.key, required this.withdrawals});

  @override
  Widget build(BuildContext context) {
    return DataTable(
      columns: const [
        DataColumn(label: Text('ID', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('User', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Amount', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Provider', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Status', style: TextStyle(color: Colors.white))),
      ],
      rows: withdrawals
          .map(
            (w) => DataRow(cells: [
              DataCell(Text(w.id.toString(), style: const TextStyle(color: Colors.white))),
              DataCell(Text(w.userName, style: const TextStyle(color: Colors.white))),
              DataCell(Text(w.amount.toString(), style: const TextStyle(color: Colors.white))),
              DataCell(Text(w.provider, style: const TextStyle(color: Colors.white))),
              DataCell(Text(w.status, style: const TextStyle(color: Colors.white))),
            ]),
          )
          .toList(),
    );
  }
}