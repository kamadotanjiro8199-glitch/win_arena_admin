import 'package:flutter/material.dart';

class ActivityCard extends StatelessWidget {
  final String activity;
  final String time;
  final VoidCallback? onTap;

  const ActivityCard({
    super.key,
    required this.activity,
    required this.time,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        color: const Color(0xff1c1c1e),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(activity, style: const TextStyle(color: Colors.white)),
              Text(time, style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}