import 'package:flutter/material.dart';

class TournamentCard extends StatelessWidget {
  final String name;
  final String type;
  final String map;
  final int entryFee;
  final int prizePool;
  final VoidCallback? onTap;

  const TournamentCard({
    super.key,
    required this.name,
    required this.type,
    required this.map,
    required this.entryFee,
    required this.prizePool,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        color: const Color(0xff1c1c1e),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              const SizedBox(height: 4),
              Text('$type | Map: $map', style: const TextStyle(color: Colors.white54)),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Entry: $entryFee PKR', style: const TextStyle(color: Colors.white70)),
                  Text('Prize: $prizePool PKR', style: const TextStyle(color: Colors.amber)),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}