import 'package:flutter/material.dart';
import '../../constants/colors.dart';
import '../../widgets/tables/users_table.dart';

class UserManagementScreen extends StatelessWidget {
  const UserManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: const Text(
          'User Management',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: const [
            Expanded(
              child: UsersTable(), // Widget from widgets/tables/users_table.dart
            ),
          ],
        ),
      ),
    );
  }
}