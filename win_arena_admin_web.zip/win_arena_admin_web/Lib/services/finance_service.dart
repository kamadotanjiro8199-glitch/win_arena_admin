import 'dart:convert';
import 'package:http/http.dart' as http;

class FinanceService {
  final String baseUrl = "https://yourwebsite.com/api";

  // Withdraw List
  Future<List<dynamic>> getWithdrawRequests() async {
    final response = await http.get(
      Uri.parse("$baseUrl/withdraw_requests.php"),
    );
    return jsonDecode(response.body);
  }

  // Approve Withdraw
  Future<Map<String, dynamic>> approveWithdraw(String wid) async {
    final response = await http.post(
      Uri.parse("$baseUrl/approve_withdraw.php"),
      body: {"withdraw_id": wid},
    );
    return jsonDecode(response.body);
  }

  // Reject Withdraw
  Future<Map<String, dynamic>> rejectWithdraw(String wid) async {
    final response = await http.post(
      Uri.parse("$baseUrl/reject_withdraw.php"),
      body: {"withdraw_id": wid},
    );
    return jsonDecode(response.body);
  }
}