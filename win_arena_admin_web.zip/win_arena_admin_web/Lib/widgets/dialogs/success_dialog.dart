import 'package:flutter/material.dart';

class SuccessDialog extends StatelessWidget {
  final String message;
  final VoidCallback? onClose;

  const SuccessDialog({super.key, required this.message, this.onClose});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xff1c1c1e),
      content: Row(
        children: [
          const Icon(Icons.check_circle, color: Colors.green, size: 36),
          const SizedBox(width: 12),
          Expanded(child: Text(message, style: const TextStyle(color: Colors.white))),
        ],
      ),
      actions: [
        ElevatedButton(
          onPressed: onClose ?? () => Navigator.pop(context),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          child: const Text('OK'),
        )
      ],
    );
  }
}