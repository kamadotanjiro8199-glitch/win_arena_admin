class AppStrings {
  AppStrings._();

  // App
  static const String appName = 'Win Arena - Admin';

  // Fixed withdrawal account (read-only in UI)
  static const String withdrawAccountName = 'Syed Asif Ali Shah';
  static const String withdrawAccountNumber = '03234227193';
  static const String withdrawAccountProvider = 'JazzCash';

  // Common labels
  static const String loginTitle = 'Admin Login';
  static const String dashboardTitle = 'Dashboard';
  static const String approveWithdrawTitle = 'Approve Withdrawals';
}