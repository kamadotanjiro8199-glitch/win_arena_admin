class AppImages {
  AppImages._();

  static const String logo = 'assets/images/logo.png';
  static const String adminBanner = 'assets/images/admin_banner.png';
  static const String splashBg = 'assets/images/splash_bg.png';
  static const String userPlaceholder = 'assets/images/user_placeholder.png';
}