import 'package:get/get.dart';
import '../models/user_model.dart';
import '../services/user_service.dart';

class UserController extends GetxController {
  final UserService _userService = UserService();

  RxBool loading = false.obs;
  RxList<UserModel> users = <UserModel>[].obs;

  Future<void> fetchUsers() async {
    loading.value = true;
    users.value = await _userService.getAllUsers();
    loading.value = false;
  }

  Future<void> blockUser(String uid) async {
    await _userService.blockUser(uid);
    fetchUsers();
  }

  Future<void> unblockUser(String uid) async {
    await _userService.unblockUser(uid);
    fetchUsers();
  }
}