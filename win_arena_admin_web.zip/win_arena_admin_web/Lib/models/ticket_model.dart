class TicketModel {
  final String id;
  final String userId;
  final String subject;
  final String message;
  final String status; // open / resolved
  final DateTime createdAt;

  TicketModel({
    required this.id,
    required this.userId,
    required this.subject,
    required this.message,
    required this.status,
    required this.createdAt,
  });

  factory TicketModel.fromJson(Map<String, dynamic> json) {
    return TicketModel(
      id: json["id"] ?? "",
      userId: json["user_id"] ?? "",
      subject: json["subject"] ?? "",
      message: json["message"] ?? "",
      status: json["status"] ?? "open",
      createdAt:
          DateTime.tryParse(json["created_at"] ?? "") ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "user_id": userId,
      "subject": subject,
      "message": message,
      "status": status,
      "created_at": createdAt.toIso8601String(),
    };
  }
}