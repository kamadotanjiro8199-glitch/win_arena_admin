import 'package:flutter/material.dart';

class AddTournamentDialog extends StatefulWidget {
  final void Function(String name, String type, int entryFee, int prizePool) onAdd;

  const AddTournamentDialog({super.key, required this.onAdd});

  @override
  State<AddTournamentDialog> createState() => _AddTournamentDialogState();
}

class _AddTournamentDialogState extends State<AddTournamentDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _typeController = TextEditingController();
  final _entryController = TextEditingController();
  final _prizeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xff1c1c1e),
      title: const Text('Add Tournament', style: TextStyle(color: Colors.white)),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(labelText: 'Tournament Name', labelStyle: TextStyle(color: Colors.white70)),
                validator: (value) => value!.isEmpty ? 'Enter name' : null,
              ),
              TextFormField(
                controller: _typeController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(labelText: 'Type', labelStyle: TextStyle(color: Colors.white70)),
                validator: (value) => value!.isEmpty ? 'Enter type' : null,
              ),
              TextFormField(
                controller: _entryController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(labelText: 'Entry Fee', labelStyle: TextStyle(color: Colors.white70)),
                keyboardType: TextInputType.number,
                validator: (value) => value!.isEmpty ? 'Enter entry fee' : null,
              ),
              TextFormField(
                controller: _prizeController,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(labelText: 'Prize Pool', labelStyle: TextStyle(color: Colors.white70)),
                keyboardType: TextInputType.number,
                validator: (value) => value!.isEmpty ? 'Enter prize pool' : null,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel', style: TextStyle(color: Colors.redAccent)),
        ),
        ElevatedButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              widget.onAdd(
                _nameController.text,
                _typeController.text,
                int.parse(_entryController.text),
                int.parse(_prizeController.text),
              );
              Navigator.pop(context);
            }
          },
          style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
          child: const Text('Add'),
        ),
      ],
    );
  }
}