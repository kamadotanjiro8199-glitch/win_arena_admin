import 'package:flutter/material.dart';
import '../../constants/colors.dart';

class AdminAccountScreen extends StatelessWidget {
  const AdminAccountScreen({super.key});

  // Fixed admin account details
  final String adminName = 'Syed Asif Ali Shah';
  final String adminNumber = '03234227193';
  final String provider = 'JazzCash';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: const Text(
          'Admin Account',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          color: AppColors.cardBackground,
          child: ListTile(
            leading: const Icon(Icons.account_circle, size: 50),
            title: Text(
              adminName,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text('Number: $adminNumber\nProvider: $provider'),
          ),
        ),
      ),
    );
  }
}