import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {
  final String baseUrl = "https://yourwebsite.com/api";

  Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await http.post(
      Uri.parse("$baseUrl/admin_login.php"),
      body: {
        "email": email,
        "password": password,
      },
    );

    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> fetchAdminProfile(String adminId) async {
    final response = await http.post(
      Uri.parse("$baseUrl/get_admin.php"),
      body: {"admin_id": adminId},
    );

    return jsonDecode(response.body);
  }
}