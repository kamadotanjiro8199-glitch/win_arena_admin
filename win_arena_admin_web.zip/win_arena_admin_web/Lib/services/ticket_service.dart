import 'dart:convert';
import 'package:http/http.dart' as http;

class TicketService {
  final String baseUrl = "https://yourwebsite.com/api";

  Future<List<dynamic>> getTickets() async {
    final response = await http.get(
      Uri.parse("$baseUrl/support_tickets.php"),
    );
    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> replyTicket(String ticketId, String reply) async {
    final response = await http.post(
      Uri.parse("$baseUrl/reply_ticket.php"),
      body: {
        "ticket_id": ticketId,
        "reply": reply,
      },
    );

    return jsonDecode(response.body);
  }
}