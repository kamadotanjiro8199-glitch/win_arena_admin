# Win Arena Admin Panel (Web)

**Platform:** Flutter Web  
**Focus:** Admin Panel for Win Arena Free Fire Tournaments  
**Theme:** Dark Gaming (Blue + Gold + Black)  
**Fixed Withdrawal Account:** Syed Asif Ali Shah - 03234227193 - JazzCash  

---

## **Overview**

Win Arena Admin Panel is a web-based application built using Flutter Web to manage Free Fire tournaments. Admins can manage users, tournaments, withdrawals, revenues, reports, payments, and app settings.  

This panel ensures smooth operations and monitoring of the tournament ecosystem.

---

## **Features**

### **Dashboard & Recent Activity**
- Overview of total users, tournaments, and transactions
- Recent activities log
- Quick access to key admin actions

### **User Management**
- View all registered users
- Edit user information
- Track player stats and wallet balances

### **Tournament Management**
- Create, edit, and delete tournaments
- Manage tournament details (Type, Map, Entry Fee, Prize Pool)
- Monitor ongoing and completed tournaments

### **Finance**
- Approve withdrawals (Fixed account only)
  - **Name:** Syed Asif Ali Shah  
  - **Number:** 03234227193  
  - **Provider:** JazzCash  
- View revenue reports

### **Reports**
- Ticket Reports
- Activity Logs

### **Payments**
- Payment setup management
- Configure supported payment providers

### **Settings**
- Admin account details
- App configuration
- Theme customization

### **Other Features**
- Dark Gaming UI Theme (Blue + Gold + Black)
- Poppins Font integration
- Responsive web design

---

## **Project Structure**