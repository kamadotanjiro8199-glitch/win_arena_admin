import 'package:flutter/material.dart';
import '../../constants/colors.dart';

class PaymentSetupScreen extends StatelessWidget {
  const PaymentSetupScreen({super.key});

  // Fixed payment account details (if needed)
  final String accountName = 'Syed Asif Ali Shah';
  final String accountNumber = '03234227193';
  final String provider = 'JazzCash';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: const Text(
          'Payment Setup',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              color: AppColors.cardBackground,
              child: ListTile(
                title: Text(
                  'Account: $accountName',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text('Number: $accountNumber\nProvider: $provider'),
                trailing: const Icon(Icons.account_balance_wallet),
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: Center(
                child: Text(
                  'Setup payment methods and details here.',
                  style: TextStyle(color: AppColors.textSecondary),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}