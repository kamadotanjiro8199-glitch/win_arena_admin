import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color primary = Color(0xFF0B57A4); // blue
  static const Color gold = Color(0xFFFFC107); // gold
  static const Color background = Color(0xFF0A0A0D); // near black
  static const Color card = Color(0xFF0F1724);
  static const Color accent = Color(0xFF00C2A8);
  static const Color text = Color(0xFFE6EEF6);
  static const Color muted = Color(0xFF97A1B0);
}