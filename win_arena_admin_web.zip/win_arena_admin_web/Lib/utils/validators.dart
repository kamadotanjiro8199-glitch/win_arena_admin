class Validators {
  static String? validateEmail(String? value) {
    if (value == null || value.isEmpty) return "Email required";
    if (!RegExp(r"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$").hasMatch(value)) {
      return "Invalid email";
    }
    return null;
  }

  static String? validatePassword(String? value) {
    if (value == null || value.isEmpty) return "Password required";
    if (value.length < 6) return "Minimum 6 characters required";
    return null;
  }

  static String? validatePhone(String? value) {
    if (value == null || value.isEmpty) return "Phone number required";

    // Pakistan phone number format (JazzCash, EasyPaisa, Bank)
    if (!RegExp(r"^(03[0-9]{9})$").hasMatch(value)) {
      return "Invalid phone number (e.g., 03001234567)";
    }

    return null;
  }

  static String? validateText(String? value, {String fieldName = "Field"}) {
    if (value == null || value.isEmpty) return "$fieldName required";
    return null;
  }

  static bool isNumeric(String value) {
    return double.tryParse(value) != null;
  }
}