import 'package:flutter/material.dart';
import '../../constants/colors.dart';
import '../../widgets/tables/tickets_table.dart';

class TicketReportsScreen extends StatelessWidget {
  const TicketReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: const Text(
          'Ticket Reports',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: const [
            Expanded(
              child: TicketsTable(), // Table widget showing all support tickets
            ),
          ],
        ),
      ),
    );
  }
}