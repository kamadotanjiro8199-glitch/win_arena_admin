import 'package:flutter/material.dart';
import '../../constants/colors.dart';
import '../../widgets/tables/tournaments_table.dart';

class TournamentManagementScreen extends StatelessWidget {
  const TournamentManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.primary,
        title: const Text(
          'Tournament Management',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: const [
            Expanded(
              child: TournamentsTable(), // Widget from widgets/tables/tournaments_table.dart
            ),
          ],
        ),
      ),
    );
  }
}