import 'package:flutter/material.dart';
import '../../models/ticket_model.dart';

class TicketsTable extends StatelessWidget {
  final List<TicketModel> tickets;

  const TicketsTable({super.key, required this.tickets});

  @override
  Widget build(BuildContext context) {
    return DataTable(
      columns: const [
        DataColumn(label: Text('ID', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('User', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Subject', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Status', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Created At', style: TextStyle(color: Colors.white))),
      ],
      rows: tickets
          .map(
            (t) => DataRow(cells: [
              DataCell(Text(t.id.toString(), style: const TextStyle(color: Colors.white))),
              DataCell(Text(t.userName, style: const TextStyle(color: Colors.white))),
              DataCell(Text(t.subject, style: const TextStyle(color: Colors.white))),
              DataCell(Text(t.status, style: const TextStyle(color: Colors.white))),
              DataCell(Text(t.createdAt.toString(), style: const TextStyle(color: Colors.white))),
            ]),
          )
          .toList(),
    );
  }
}