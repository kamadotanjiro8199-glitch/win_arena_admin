import 'package:get/get.dart';
import '../models/wallet_model.dart';
import '../services/finance_service.dart';

class FinanceController extends GetxController {
  final FinanceService _financeService = FinanceService();

  RxBool loading = false.obs;
  RxList<WithdrawRequestModel> withdrawRequests = <WithdrawRequestModel>[].obs;

  Future<void> fetchWithdrawRequests() async {
    loading.value = true;
    withdrawRequests.value = await _financeService.getWithdrawRequests();
    loading.value = false;
  }

  Future<void> approveWithdraw(String requestId) async {
    await _financeService.approveWithdraw(requestId);
    fetchWithdrawRequests();
  }

  Future<void> rejectWithdraw(String requestId) async {
    await _financeService.rejectWithdraw(requestId);
    fetchWithdrawRequests();
  }
}