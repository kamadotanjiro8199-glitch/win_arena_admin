class WalletTransaction {
  final String id;
  final String userId;
  final String type; // withdraw
  final int amount;
  final String status; // pending / approved / rejected
  final DateTime date;

  WalletTransaction({
    required this.id,
    required this.userId,
    required this.type,
    required this.amount,
    required this.status,
    required this.date,
  });

  factory WalletTransaction.fromJson(Map<String, dynamic> json) {
    return WalletTransaction(
      id: json["id"] ?? "",
      userId: json["user_id"] ?? "",
      type: json["type"] ?? "",
      amount: json["amount"] ?? 0,
      status: json["status"] ?? "pending",
      date: DateTime.tryParse(json["date"] ?? "") ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "user_id": userId,
      "type": type,
      "amount": amount,
      "status": status,
      "date": date.toIso8601String(),
    };
  }
}