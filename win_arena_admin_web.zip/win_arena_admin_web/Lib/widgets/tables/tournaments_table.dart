import 'package:flutter/material.dart';
import '../../models/tournament_model.dart';

class TournamentsTable extends StatelessWidget {
  final List<TournamentModel> tournaments;

  const TournamentsTable({super.key, required this.tournaments});

  @override
  Widget build(BuildContext context) {
    return DataTable(
      columns: const [
        DataColumn(label: Text('ID', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Name', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Type', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Entry Fee', style: TextStyle(color: Colors.white))),
        DataColumn(label: Text('Prize Pool', style: TextStyle(color: Colors.white))),
      ],
      rows: tournaments
          .map(
            (t) => DataRow(cells: [
              DataCell(Text(t.id.toString(), style: const TextStyle(color: Colors.white))),
              DataCell(Text(t.name, style: const TextStyle(color: Colors.white))),
              DataCell(Text(t.type, style: const TextStyle(color: Colors.white))),
              DataCell(Text(t.entryFee.toString(), style: const TextStyle(color: Colors.white))),
              DataCell(Text(t.prizePool.toString(), style: const TextStyle(color: Colors.white))),
            ]),
          )
          .toList(),
    );
  }
}